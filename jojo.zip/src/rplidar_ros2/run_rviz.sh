#!/bin/bash
source ./install/setup.bash
rviz2 ./install/rplidar_ros/share/rplidar_ros/rviz/rplidar.rviz

















