#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import smbus
import math
from tf_transformations import euler_from_quaternion,quaternion_from_euler
from math import sin, cos, pi
import tf2_ros,tf2_py
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3, PoseWithCovarianceStamped, TwistWithCovariance
import pymodbus
import serial
from pymodbus.pdu import ModbusRequest
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
import time
import numpy as np


# Initial conditions
ser = serial.Serial()
ser.port = '/dev/ttyUSB1' #for linux. Also change the USB# to the correct # if necessary.
#ser.port = 'COM7' 
ser.baudrate = 9600
ser.parity = 'N'
ser.bytesize = 8
ser.timeout = 1
ser.open()

def imu_pub(args=None):
	rclpy.init(args=args)
	node = Node('imu_node')
	publisher = node.create_publisher(Imu, '/imu/data_raw', 50)
	# publisher2 = node.create_publisher(TwistWithCovariance,'/imu/msg_pose',50)
	start_time = node.get_clock().now()
	current_time = node.get_clock().now()
	last_time = node.get_clock().now()
	global yaw_
	roll_ = 0
	#yaw_ = 0
	pitch_ = 0
	rate = node.create_rate(50)
	yaw_ = 0.0


	readData = ""
	dataStartRecording = False

	# This part is needed so that the reading can start reliably.
	print('Starting...', ser.name)
	time.sleep(1)
	ser.reset_input_buffer()
	while rclpy.ok():
		rawData = ser.read(size=2).hex()
		if rawData == '5551':
			dataStartRecording = True
		
		# Recording and concatenation functions
		if dataStartRecording == True:
			readData = readData + rawData
			
		# Processing. Varaible names based on variables on the Witmotion WT901CTTL datasheet.
			if len(readData) == 88:
				StartAddress_1 = int(readData[0:2], 16)
				StartAddress_A = int(readData[2:4], 16)
				AxL = int(readData[4:6], 16)
				AxH = int(readData[6:8], 16)
				AyL = int(readData[8:10], 16)
				AyH = int(readData[10:12], 16)
				AzL = int(readData[12:14], 16)
				AzH = int(readData[14:16], 16)
				TL_A = int(readData[16:18], 16)
				TH_A = int(readData[18:20], 16)
				SUM_A = int(readData[20:22], 16)
				
				StartAddress_2 = int(readData[22:24], 16)
				StartAddress_w = int(readData[24:26], 16)
				wxL = int(readData[26:28], 16)
				wxH = int(readData[28:30], 16)
				wyL = int(readData[30:32], 16)
				wyH = int(readData[32:34], 16)
				wzL = int(readData[34:36], 16)
				wzH = int(readData[36:38], 16)
				TL_w = int(readData[38:40], 16)
				TH_w = int(readData[40:42], 16)
				SUM_w = int(readData[42:44], 16)
				
				StartAddress_3 = int(readData[44:46], 16)
				StartAddress_ypr = int(readData[46:48], 16)
				RollL = int(readData[48:50], 16)
				RollH = int(readData[50:52], 16)
				PitchL = int(readData[52:54], 16)
				PitchH = int(readData[54:56], 16)
				YawL = int(readData[56:58], 16)
				YawH = int(readData[58:60], 16)
				VL = int(readData[60:62], 16)
				VH = int(readData[62:64], 16)
				SUM_ypr = int(readData[64:66], 16)
				
				StartAddress_4 = int(readData[66:68], 16)
				StartAddress_mag = int(readData[68:70], 16)
				HxL = int(readData[70:72], 16)
				HxH = int(readData[72:74], 16)
				HyL = int(readData[74:76], 16)
				HyH = int(readData[76:78], 16)
				HzL = int(readData[78:80], 16)
				HzH = int(readData[80:82], 16)
				TL_mag = int(readData[82:84], 16)
				TH_mag = int(readData[84:86], 16)
				SUM_mag = int(readData[86:88], 16)
		
				# Acceleration output
				Ax = float(np.array((AxH << 8) | AxL).astype(np.int16) / 32768.0 * 16.0)
				Ay = float(np.array((AyH << 8) | AyL).astype(np.int16) / 32768.0 * 16.0)
				Az = float(np.array((AzH << 8) | AzL).astype(np.int16) / 32768.0 * 16.0)
				T_A = float(np.array((TH_A << 8) | TL_A).astype(np.int16) / 100.0)

				# Angular velocity outputs
				Wx = float(np.array((wxH << 8) | wxL).astype(np.int16) / 32768.0 * 2000.0)
				Wy = float(np.array((wyH << 8) | wyL).astype(np.int16) / 32768.0 * 2000.0)
				Wz = float(np.array((wzH << 8) | wzL).astype(np.int16) / 32768.0 * 2000.0)
				T_w = float(np.array((TH_w << 8) | TL_w).astype(np.int16) / 100.0)

				# Angle output
				Roll = float(np.array((RollH << 8) | RollL).astype(np.int16) / 32768.0 * 180.0)
				Pitch = float(np.array((PitchH << 8) | PitchL).astype(np.int16) / 32768.0 * 180.0)
				Yaw = float(np.array((YawH << 8) | YawL).astype(np.int16) / 32768.0 * 180.0)
				Yaw=Yaw/180.0
				# Magnetic output
				Hx = float(np.array((HxH << 8) | HxL).astype(np.int16))
				Hy = float(np.array((HyH << 8) | HyL).astype(np.int16))
				Hz = float(np.array((HzH << 8) | HzL).astype(np.int16))
				T_mag = float(np.array((TH_mag << 8) | TL_mag).astype(np.int16) / 100.0)
				#modbus_q = client.read_holding_registers(address=0x50, count=4, unit=0x50)
				quat = Quaternion()
				quat.x, quat.y, quat.z, quat.w =quaternion_from_euler(0.0, 0.0 , Yaw)
				i = Imu()
				i.header.stamp = node.get_clock().now().to_msg()
				i.header.frame_id = 'imu_frame'
				# i.orientation.x = quat[0]#modbus.registers[22]/32768
				# i.orientation.y = quat[1]#modbus.registers[23]/32768
				# i.orientation.z = quat[2]#modbus.registers[24]/32768
				# i.orientation.w = quat[3]#modbus.registers[25]/32768
				i.orientation.x =quat.x
				i.orientation.y=quat.y
				i.orientation.z= quat.z
				i.orientation.w= quat.w
				i.angular_velocity.x = Roll
				i.angular_velocity.y = Pitch
				i.angular_velocity.z = Yaw
				i.linear_acceleration.x = Ax
				i.linear_acceleration.y = Ay
				i.linear_acceleration.z = Az
				publisher.publish(i)
				print('enviando',Roll,Pitch,Yaw)

				readData = ""
				dataStartRecording = False


if __name__ == '__main__':
    imu_pub()

