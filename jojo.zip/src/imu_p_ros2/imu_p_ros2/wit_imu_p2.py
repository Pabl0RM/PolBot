#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import smbus
import math
from tf_transformations import euler_from_quaternion,quaternion_from_euler
from math import sin, cos, pi
import tf2_ros,tf2_py
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3, PoseWithCovarianceStamped, TwistWithCovariance
import pymodbus
import serial
from pymodbus.pdu import ModbusRequest
from pymodbus.client.sync import ModbusSerialClient as ModbusClient

def read_byte(reg):
    return bus.read_byte_data(address, reg)

def read_word(reg):
    h = bus.read_byte_data(address, reg)
    l = bus.read_byte_data(address, reg+1)
    value = (h << 8) + l
    return value


def read_word_2c(reg):
    val = read_word(reg)
    if (val >= 0x8000):
        return -((65535 - val) + 1)
    else:
        return val
yaw_ = 0.0
address = 0x55       # via i2cdetect

client = ModbusClient(method='rtu',port='/dev/ttyUSB0',parity='N',stopbits=1,bytesize=8,baudrate=115200,timeout=3)
if client.connect:
        try:
                print('Conectado')
        except:
                print('Non conectado')

def imu_pub(args=None):
    rclpy.init(args=args)
    node = Node('imu_node')
    publisher = node.create_publisher(Imu, '/imu/msg_imu', 50)
#    publisher2 = node.create_publisher(TwistWithCovariance,'/imu/msg_pose',50)





    start_time = node.get_clock().now()
    current_time = node.get_clock().now()
    last_time = node.get_clock().now()
    global yaw_
    roll_ = 0
    #yaw_ = 0
    pitch_ = 0
    rate = node.create_rate(50)
    while rclpy.ok():
        modbus = client.read_holding_registers(address=0x34, count=26, unit=0x50)

        roll = modbus.registers[3]/32768*2000*3.1415926536/180
        pitch = modbus.registers[4]/32768*2000*3.1415926536/180
        yaw = modbus.registers[5]/32768*2000*3.1415926536/180

        roll_= modbus.registers[9]*3.1415926536/ 32768
        picht_ = modbus.registers[10]*3.1415926536/ 32768
        yaw_ = (modbus.registers[11]*3.1415926536/ 32768)-3.1415926536
        #yaw_ = yaw_ +yaw
        proba=0.0
        proba= modbus.registers[11] / 32768
        #print(yaw_)
        #print(proba)

        quat = quaternion_from_euler(0.0, 0.0 , yaw_)
        quat = Quaternion()
        quat.x, quat.y, quat.z, quat.w =quaternion_from_euler(0.0, 0.0 , yaw_)
        a_x = modbus.registers[0]/32768*16*9.8
        a_y = modbus.registers[1]/32768*16*9.8
        a_z = modbus.registers[2]/32768*16*9.8

        #modbus_q = client.read_holding_registers(address=0x50, count=4, unit=0x50)

        i = Imu()
        i.header.stamp = node.get_clock().now().to_msg()
        i.header.frame_id = 'imu_frame'
        # i.orientation.x = quat[0]#modbus.registers[22]/32768
        # i.orientation.y = quat[1]#modbus.registers[23]/32768
        # i.orientation.z = quat[2]#modbus.registers[24]/32768
        # i.orientation.w = quat[3]#modbus.registers[25]/32768
        i.orientation.x =quat.x
        i.orientation.y=quat.y
        i.orientation.z= quat.z
        i.orientation.w= quat.w
        i.angular_velocity.x = roll
        i.angular_velocity.y = pitch
        i.angular_velocity.z = yaw
        i.linear_acceleration.x = a_x
        i.linear_acceleration.y = a_y
        i.linear_acceleration.z = a_z
        publisher.publish(i)

   #rospy.init_node('imu_node', anonymous=True)
   #whil#e not rospy.is_shutdown():
#        p = TwistWithCovariance()
 #       p.header.frame_id = "laser_frame"
  #      p.header.stamp = node.get_clock().now().to_msg()

   #     modbus_p = client.read_holding_registers(address=0x3d, count=3, unit=0x50)
    ##    p.twist.linear.x = 0
      #  p.twist.linear.y = 0
       # p.twist.linear.z = 0
        # Make sure the quaternion is valid and normalized
#        p.twist.angular.x = modbus_p.registers[0]*3.1415926536/ 32768
 #       p.twist.angular.y = modbus_p.registers[1]*3.1415926536/ 32768
  #      p.twist.angular.z = modbus_p.registers[2]*3.1415926536/ 32768
   #     p.pose.pose.orientation.w = 1.0
    #    p.covariance = [0.000,0.0,0.0,0.0,0.0,0.0,
     #                   0.0,0.000,0.0,0.0,0.0,0.0,
      #                  0.0,0.0,0.000,0.0,0.0,0.0,
       #                 0.0,0.0,0.0,0.00000,0.0,0.0,
        #                0.0,0.0,0.0,0.0,0.00000,0.0,
         #               0.0,0.0,0.0,0.0,0.0,0.00017]
        


#        publisher2.publish(p)
#        rclpy.spin(node)
 #       rate.sleep()



if __name__ == '__main__':
    imu_pub()
